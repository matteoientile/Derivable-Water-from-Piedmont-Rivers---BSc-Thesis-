VERSIONE DEFINITIVA

# TESI: Confronto tra diverse metodologie statistiche per la quantificazione dei volumi derivabili da un corso d'acqua

In idrologia, la stima del volume derivabile da una certa sezione di un corso d'acqua non è banale, poiché non è nota a priori la disponibilità idrica futura. Per ovviare a questa incertezza intrinseca del problema, esistono alcuni approcci di tipo statistico-probabilistico che conducono alla stima del volume derivabile, sulla base delle misurazioni di portata degli anni precedenti.

In questo studio vengono messi al vaglio i due principali metodi:
1) APPROCCIO MULTI-ANNO: si esegue uno studio annuale, cioè si calcola il volume derivabile mensile per ogni anno a partire dalle portate. Dopodiché, si confrontano i valori e si calcolano alcuni indicatori statistici (media, varianza).
2) APPROCCIO SULL'ANNO TIPO: si esegue uno studio su due anni di riferimento, "anno medio" e "anno scarso". Il primo è costituito da 365 misurazioni di portata, ognuna pari alla media delle portate giornaliere degli anni in esame; più precisamente vengono riordinati i dataset annuali in ordine crescente e vengono mediate le portate (e.g. la portata più piccola dell'anno medio sarà la media delle portate più piccole di ogni anno $\dots$). Il secondo invece si ottiene con la stessa logica, tuttavia al posto della media viene considerato il quantile 0.2 . Ottenuti gli anni di riferimento, si eseguono anche qui le analisi statistiche del caso.

Infine, si fa un confronto tra le due metodologie mettendo in luce le differenze.

Questo applicativo si propone di ricevere in input le serie storiche delle portate giornaliere di alcune stazioni di misura (a cura di $\href{https://www.arpa.piemonte.it/rischi_naturali/snippets_arpa_graphs/map_meteoweb/?rete=stazione_meteorologica}{ARPA\,Piemonte}$) ed eseguire tutti i passaggi necessari per ottenere un'analisi statistica sui volumi derivabili.

## Stazioni in esame

Le stazioni prese in esame per l'analisi in questione sono le seguenti, tuttavia il codice funzionerebbe in modo del tutto analogo al variare di esse.
- Stazione ALBA TANARO
- Stazione ANDONNO GESSO
- Stazione CARIGNANO PO
- Stazione SAN SEBASTIANO PO
- Stazioene VEROLENGO DORA BALTEA

I criteri alla base della selezioni sono i seguenti
- Si prediligono stazioni con uno storico significativo di dati 
- Si prediligono stazioni dotate di misurazioni recenti


```python
#Pacchetti utili
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
# Dataframe in esame
df_carignano = pd.read_csv(r"C:\Users\MATTEO IENTILE\Desktop\TESI\Codice sorgente tesi\CARIGNANO PO.csv") 
df_po = pd.read_csv(r"C:\Users\MATTEO IENTILE\Desktop\TESI\Codice sorgente tesi\SAN SEBASTIANO PO.csv") 
df_gesso = pd.read_csv(r"C:\Users\MATTEO IENTILE\Desktop\TESI\Codice sorgente tesi\ANDONNO GESSO.csv") 
df_tanaro = pd.read_csv(r"C:\Users\MATTEO IENTILE\Desktop\TESI\Codice sorgente tesi\ALBA TANARO.csv") 
df_dora = pd.read_csv(r"C:\Users\MATTEO IENTILE\Desktop\TESI\Codice sorgente tesi\VEROLENGO DORA BALTEA.csv") 

dataframes = [df_carignano, df_po, df_gesso, df_tanaro, df_dora]
```

## 1) Data collection and data exploration

Per prima cosa, si rende necessario visualizzare i dati a disposizione e verificare l'eventuale necessità di gestire casi particolari. Un tipico esempio potrebbe essere l'assenza di misurazioni per un certo periodo di tempo (e.g. guasto di un sensore).


```python
#VISUALIZZAZIONE df IN ESAME
dataframes
```




    [            DATA  Livello idrometrico fiume (m)  Portata fiume (m³/s)
     0     2007-01-01                           0.93                 27.50
     1     2007-01-02                           0.91                 26.20
     2     2007-01-03                           0.93                 27.70
     3     2007-01-04                           0.95                 29.90
     4     2007-01-05                           0.95                 29.90
     ...          ...                            ...                   ...
     6204  2023-12-27                           1.00                 23.79
     6205  2023-12-28                           0.99                 22.73
     6206  2023-12-29                           0.99                 22.82
     6207  2023-12-30                           0.98                 22.62
     6208  2023-12-31                           0.99                 23.18
     
     [6209 rows x 3 columns],
                 DATA  Livello idrometrico fiume (m)  Portata fiume (m³/s)
     0     2007-02-28                           1.18                 58.90
     1     2007-03-01                           1.27                 75.30
     2     2007-03-02                           1.27                 74.60
     3     2007-03-03                           1.22                 63.50
     4     2007-03-04                           1.21                 61.90
     ...          ...                            ...                   ...
     6146  2023-12-27                           1.04                 32.35
     6147  2023-12-28                           1.03                 31.86
     6148  2023-12-29                           0.98                 24.77
     6149  2023-12-30                           0.99                 26.04
     6150  2023-12-31                           0.99                 26.06
     
     [6151 rows x 3 columns],
                 DATA  Livello idrometrico fiume (m)  Portata fiume (m³/s)
     0     2008-01-01                           0.61                  1.46
     1     2008-01-02                           0.61                  1.51
     2     2008-01-03                           0.61                  1.57
     3     2008-01-04                           0.62                  1.70
     4     2008-01-05                           0.61                  1.61
     ...          ...                            ...                   ...
     5839  2023-12-27                           0.70                  1.58
     5840  2023-12-28                           0.70                  1.54
     5841  2023-12-29                           0.70                  1.55
     5842  2023-12-30                           0.69                  1.33
     5843  2023-12-31                           0.69                  1.33
     
     [5844 rows x 3 columns],
                 DATA  Livello idrometrico fiume (m)  Portata fiume (m³/s)
     0     2007-01-01                          -0.63                 26.30
     1     2007-01-02                          -0.63                 26.20
     2     2007-01-03                          -0.64                 25.10
     3     2007-01-04                          -0.63                 26.10
     4     2007-01-05                          -0.64                 25.50
     ...          ...                            ...                   ...
     6204  2023-12-27                            NaN                 24.87
     6205  2023-12-28                            NaN                 24.30
     6206  2023-12-29                            NaN                 23.57
     6207  2023-12-30                            NaN                 22.88
     6208  2023-12-31                            NaN                 23.06
     
     [6209 rows x 3 columns],
                 DATA  Livello idrometrico fiume (m)  Portata fiume (m³/s)
     0     2002-01-01                           0.50                 22.20
     1     2002-01-02                           0.33                 15.50
     2     2002-01-03                           0.48                 21.00
     3     2002-01-04                           0.54                 23.60
     4     2002-01-05                           0.68                 31.00
     ...          ...                            ...                   ...
     8030  2023-12-27                           1.11                 30.00
     8031  2023-12-28                           1.10                 28.49
     8032  2023-12-29                           1.10                 28.48
     8033  2023-12-30                           1.09                 27.13
     8034  2023-12-31                           1.09                 27.39
     
     [8035 rows x 3 columns]]



Si osserva che per il secondo dataset della lista (df_po) le misurazioni partono dal 28 di febbraio del 2007. In questi casi l'opzione migliore è scartare l'intero anno. 


```python
#VERIFICA DELLA PRESENZA DI DATI MANCANTI
for df in dataframes:
    print(df.isna().sum())
```

    DATA                              0
    Livello idrometrico fiume (m)    99
    Portata fiume (m³/s)              0
    dtype: int64
    DATA                             0
    Livello idrometrico fiume (m)    4
    Portata fiume (m³/s)             0
    dtype: int64
    DATA                             0
    Livello idrometrico fiume (m)    0
    Portata fiume (m³/s)             0
    dtype: int64
    DATA                              0
    Livello idrometrico fiume (m)    82
    Portata fiume (m³/s)              0
    dtype: int64
    DATA                               0
    Livello idrometrico fiume (m)    118
    Portata fiume (m³/s)               0
    dtype: int64
    

Non sono presenti dati mancanti in merito ai valori di portata


```python
#VISUALIZZAZIONE DEL TIPO DI DATO
for df in dataframes:
    print(df.dtypes)
```

    DATA                              object
    Livello idrometrico fiume (m)    float64
    Portata fiume (m³/s)             float64
    dtype: object
    DATA                              object
    Livello idrometrico fiume (m)    float64
    Portata fiume (m³/s)             float64
    dtype: object
    DATA                              object
    Livello idrometrico fiume (m)    float64
    Portata fiume (m³/s)             float64
    dtype: object
    DATA                              object
    Livello idrometrico fiume (m)    float64
    Portata fiume (m³/s)             float64
    dtype: object
    DATA                              object
    Livello idrometrico fiume (m)    float64
    Portata fiume (m³/s)             float64
    dtype: object
    

Si noti che la colonna ["DATA"] è riconosciuta come object, ma per le analisi che seguiranno sarà utile farla intendere al programma come una data vera e propria, costituita da giorno, mese e anno.

Inoltre, in idrologia è buona norma eliminare il 29 febbraio negli anni bisestili.

## 2) Data cleaning and data manipulation

Si procede alle operazioni individuate nello step precedente.


```python
#1) RIMOZIONE DELLA COLONNA "Livello idrometrico fiume (m)", 2) CONVERSIONE DELLA COLONNA "DATA" IN dtype=datetime, 3) RIMOZIONE 29 FEBBRAIO
for df in dataframes:
    df.drop("Livello idrometrico fiume (m)", axis=1, inplace=True) #1)
    df["DATA"] =  pd.to_datetime(df["DATA"], format="%Y-%m-%d") #2)
    df.drop(df[(df["DATA"].dt.month == 2) & (df["DATA"].dt.day == 29)].index, inplace=True) #3)

#RIMOZIONE DELL'ANNO 2007 DAL df_po
df_po = df_po[~((df_po["DATA"].dt.year == 2007))]
```

Per le analisi che seguono risulta utile, dato un dataframe, suddividerlo in "sotto-dataframe" annuali. 

Per far questo, il modo migliore è creare una funzione che, ricevuto in input un df sia in grado di eseguire questa operazione. Inoltre, nella stessa funzione è utile già implementare qualche altra operazione:
- riordinare i df annuali per portate crescenti
- creare le colonne $d$ e $F sup$, rispettivamente la durata e la frequenza di superamento (ottenuta con la plotting position di Weibull). 


```python
#FUNZIONE CHE SUDDIVIDE df ANNO PER ANNO E CALCOLA Fsup
def edit_dataframe(df):
    years_analysis = {}
    first_year = df["DATA"].iloc[0].year
    last_year = df["DATA"].iloc[-1].year
    for year in np.arange(first_year, last_year + 1, 1):
        df_annual = df[df["DATA"].dt.year == year]
        years_analysis[year] = df_annual
        
    for year, df in years_analysis.items():
        df = df.sort_values("Portata fiume (m³/s)")
        df["d"] = np.arange(365, 0, -1)
        df["F sup"] = df["d"] / 366
        years_analysis[year] = df
    return years_analysis

#INSERIMENTO DEI df IN UNA LISTA: il primo elemento fornisce il df_carignano diviso per anno, il secondo il df_po etc.
dataframes = [df_carignano, df_po, df_gesso, df_tanaro, df_dora]
edited_dfs = [edit_dataframe(df) for df in dataframes]
```

Per accedere alla lista si utilizzi questa nomenclatura: 

$edited\_ dfs[elemento\,\,lista][anno\,\,di\,\,interesse]$

Per esempio, il comando edited_dfs[0][2007] stamperà, sottoforma di dataset, l'anno 2007 del df_carignano ordinato per valori di portata crescente e con $d$ e $F\,sup$


```python
edited_dfs[0][2007]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DATA</th>
      <th>Portata fiume (m³/s)</th>
      <th>d</th>
      <th>F sup</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>254</th>
      <td>2007-09-12</td>
      <td>8.2</td>
      <td>365</td>
      <td>0.997268</td>
    </tr>
    <tr>
      <th>205</th>
      <td>2007-07-25</td>
      <td>10.5</td>
      <td>364</td>
      <td>0.994536</td>
    </tr>
    <tr>
      <th>210</th>
      <td>2007-07-30</td>
      <td>11.0</td>
      <td>363</td>
      <td>0.991803</td>
    </tr>
    <tr>
      <th>209</th>
      <td>2007-07-29</td>
      <td>11.5</td>
      <td>362</td>
      <td>0.989071</td>
    </tr>
    <tr>
      <th>207</th>
      <td>2007-07-27</td>
      <td>11.7</td>
      <td>361</td>
      <td>0.986339</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>160</th>
      <td>2007-06-10</td>
      <td>135.0</td>
      <td>5</td>
      <td>0.013661</td>
    </tr>
    <tr>
      <th>124</th>
      <td>2007-05-05</td>
      <td>158.0</td>
      <td>4</td>
      <td>0.010929</td>
    </tr>
    <tr>
      <th>159</th>
      <td>2007-06-09</td>
      <td>160.0</td>
      <td>3</td>
      <td>0.008197</td>
    </tr>
    <tr>
      <th>157</th>
      <td>2007-06-07</td>
      <td>179.0</td>
      <td>2</td>
      <td>0.005464</td>
    </tr>
    <tr>
      <th>158</th>
      <td>2007-06-08</td>
      <td>239.0</td>
      <td>1</td>
      <td>0.002732</td>
    </tr>
  </tbody>
</table>
<p>365 rows × 4 columns</p>
</div>



### 2.1) Determinazione del deflusso ecologico

A seguito del $\href{http://arianna.cr.piemonte.it/regolafo/dettaglioRegolamento.do?urnRegolamento=urn:nir:regione.piemonte:regolamento:2021-12-27;14}{Regolamento\,\,Regionale}$ vigente dal 28/12/2021, il prelievo dai corsi d'acqua deve tener conto di una certa portata minima da rilasciare in alveo: il Deflusso ecologico $DE = k \cdot q_{meda} \cdot S\cdot M \cdot A \cdot Z \cdot T = DMV_{base}\cdot Z \cdot T$. 

Per il calcolo dei coefficienti presenti nella formula si fa riferimento agli Allegati del Regolamento sopra citato. Ai fini di una maggior precisione nella determinazione dei parametri si fa uso del $\href{https://geoportale.arpa.piemonte.it/app/public/?pg=mappa&ids=cc7a350009fe49d0bb97e517bb3299d6}{Geoportale}$ di ARPA Piemonte. Inoltre, può essere per le definizioni "Alto Po" e "Basso Po" il $\href{https://www.regione.piemonte.it/web/temi/ambiente-territorio/ambiente/acqua/piano-tutela-delle-acque-aggiornamento-2021}{PTA\,\,2021}$

Codici (da Geoportale): 
- Alba Tanaro: 05SS4N803PI
- Andonno Gesso: 04SS3N225PI
- Carignano Po: 06SS4D382PI
- San Sebastiano Po: 06SS4D384PI
- Verolengo Dora: 06GH4F168PI


```python
# 1) FATTORE "k" (da ALLEGATO B) 
k_albatanaro = 0.10 
k_andonnogesso = 0.15
k_carignanopo = 0.10 # "basso Po" dal PTA 2007, pagina 119/320 e TAV A2.12 
k_sansebpo = 0.10 # "basso Po" dal PTA 2007, pagina 119/320 e TAV A2.12
k_verolengodorab = 0.13
```
Per la determinazione dell'estensione del bacino si seguono le indiciazioni dell'allegato B, cioè si ricerca il codice del fiume (ottenuto dal Geoportale) nell'allegato 3a del bilancio idrico regionale.

```python
# 2) ESTENSIONE BACINO "S" (da INDICAZIONE ALLEGATO B -> https://www.regione.piemonte.it/web/sites/default/files/media/documenti/2019-01/pta2018_allegato_3a_bilancio_idrico_regionale_delle_acque_superficiali.pdf)
S_albatanaro = 3579 #km^2
S_andonnogesso = 354 #km^2
S_carignanopo = 3878 #km^2
S_sansebpo = 9188 #km^2
S_verolengodorab = 3942 #km^2
```


```python
# 3) FATTORE "Z" (da ALLEGATO C matchando il codice identificativo, Z=1 in assenza di matching)
Z_albatanaro = 1
Z_andonnogesso = 1.5
Z_carignanopo = 1
Z_sansebpo = 1 
Z_verolengodorab = 1.5 
```


```python
# 4) FATTORE "M" (da PTA2007_tav2.12 + Geoportale, visualizzazione bacini secondari)
M_albatanaro = 1.10 #(classe 3)
M_andonnogesso = 0.9 #(classe 1)
M_carignanopo = 1.10 #(classe 3)
M_sansebpo = 1.10 #(classe 3)
M_verolengodorab = 1.10 # (classe 3)
```


```python
# 5) FATTORE "A" (da TAV 2.12)
A_albatanaro = 1 # il tratto non va corretto. 
A_andonnogesso = 1 # il tratto in esame non va corretto, secondo la TAV 2.12
A_carignanopo = 1 #Al02, classe 3
A_sansebpo = 1 # ALl02, classe 3
A_verolengodorab = 1 # Al15, classe 2
```


```python
# 6) FATTORE "T" (da ALLEGATO C): si realizzano dei dataframe fatti in questo modo: T|mese

mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno','luglio', 'agosto', 'settembre','ottobre', 'novembre', 'dicembre']

T_albatanaro = [1, 1, 1, 2, 2, 2, 0.7, 0.7, 0.7, 0.7, 0.7, 1] #gruppo C
T_albatanarodf = pd.DataFrame(T_albatanaro, columns=['T']) 
T_albatanarodf["mese"] = mesi

T_andonnogesso = [1, 1, 1, 2, 2, 2, 0.7, 0.7, 0.7, 0.7, 0.7, 1] #gruppo C
T_andonnogessodf = pd.DataFrame(T_albatanaro, columns=['T'])
T_andonnogessodf["mese"] = mesi

T_carignanopo = [1, 1, 1, 1.8, 1.8, 1.8, 0.7, 0.7, 0.7, 0.7, 1, 1] #gruppo F
T_carignanopodf = pd.DataFrame(T_albatanaro, columns=['T'])
T_carignanopodf["mese"] = mesi

T_sansebpo =  [1, 1, 1, 1.8, 1.8, 1.8, 0.7, 0.7, 0.7, 0.7, 1, 1] #gruppo F
T_sansebpodf = pd.DataFrame(T_albatanaro, columns=['T'])
T_sansebpodf["mese"] = mesi

T_verolengodorab = [0.7, 0.7, 1, 1, 1.8, 1.8, 1, 1, 1, 1, 1, 0.7]  #gruppo D
T_verolengodorabdf = pd.DataFrame(T_albatanaro, columns=['T'])
T_verolengodorabdf["mese"] = mesi 
```


```python
#ESEMPIO DEL df CREATO
#T_sansebpodf
```


```python
# 7) FATTORE q_meda=Q_media/S (da ALLEGATO C)

Qm_albatanaro = np.mean(df_tanaro["Portata fiume (m³/s)"])
Qm_andonnogesso = np.mean(df_gesso["Portata fiume (m³/s)"])
Qm_carignanopo = np.mean(df_carignano["Portata fiume (m³/s)"])
Qm_sansebpo = np.mean(df_po["Portata fiume (m³/s)"])
Qm_verolengodorab = np.mean(df_dora["Portata fiume (m³/s)"])

qm_albatanaro = (Qm_albatanaro*1000) / S_albatanaro #l/(s*km^2)
qm_andonnogesso = (Qm_andonnogesso*1000) /  S_andonnogesso
qm_carignanopo = (Qm_carignanopo *1000) / S_carignanopo
qm_sansebpo = (Qm_sansebpo *1000) / S_sansebpo
qm_verolengodorab = (Qm_verolengodorab*1000) / S_verolengodorab
```


```python
#DETERMINAZIONE DE: si calcolano i valori di deflusso ecologico per ogni mese e si mettono all'interno di una lista "DE_nomestazione". L'elemento 0 sarà il DE di gennaio, e così via.

DE_albatanaro = []
for T in T_albatanarodf["T"]:
    DE = k_albatanaro*qm_albatanaro*S_albatanaro*A_albatanaro*M_albatanaro*Z_albatanaro*T
    DE_albatanaro.append(DE/1000)
T_albatanarodf["DE (mc/s)"] = DE_albatanaro

DE_andonnogesso = []
for T in T_andonnogessodf["T"]:
    DE = k_albatanaro*qm_albatanaro*S_albatanaro*A_albatanaro*M_albatanaro*Z_albatanaro*T
    DE_andonnogesso.append(DE/1000)
T_andonnogessodf["DE (mc/s)"] = DE_andonnogesso

DE_carignanopo = []
for T in T_carignanopodf["T"]:
    DE = k_albatanaro*qm_albatanaro*S_albatanaro*A_albatanaro*M_albatanaro*Z_albatanaro*T
    DE_carignanopo.append(DE/1000)
T_carignanopodf["DE (mc/s)"] = DE_carignanopo

DE_sansebpo = []
for T in T_sansebpodf["T"]:
    DE = k_albatanaro*qm_albatanaro*S_albatanaro*A_albatanaro*M_albatanaro*Z_albatanaro*T
    DE_sansebpo.append(DE/1000)
T_sansebpodf["DE (mc/s)"] = DE_sansebpo

DE_verolengodorab = []
for T in T_verolengodorabdf["T"]:
    DE = k_albatanaro*qm_albatanaro*S_albatanaro*A_albatanaro*M_albatanaro*Z_albatanaro*T
    DE_verolengodorab.append(DE/1000)
T_verolengodorabdf["DE (mc/s)"] = DE_verolengodorab
```


```python
#ESEMPIO DI COSA SI È OTTENUTO:
T_sansebpodf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>T</th>
      <th>mese</th>
      <th>DE (mc/s)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>gennaio</td>
      <td>7.126030</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>febbraio</td>
      <td>7.126030</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>marzo</td>
      <td>7.126030</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2.0</td>
      <td>aprile</td>
      <td>14.252059</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2.0</td>
      <td>maggio</td>
      <td>14.252059</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2.0</td>
      <td>giugno</td>
      <td>14.252059</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.7</td>
      <td>luglio</td>
      <td>4.988221</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.7</td>
      <td>agosto</td>
      <td>4.988221</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.7</td>
      <td>settembre</td>
      <td>4.988221</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.7</td>
      <td>ottobre</td>
      <td>4.988221</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.7</td>
      <td>novembre</td>
      <td>4.988221</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1.0</td>
      <td>dicembre</td>
      <td>7.126030</td>
    </tr>
  </tbody>
</table>
</div>



### 2.2) Calcolo della portata depurata del Deflusso Ecologico e Volume giornaliero derivabile

Per la determinazione del volume derivabile si deve depurare la portata del fiume del valore di DE, tenendo sempre conto che l'ipotetica opera di presa può derivare al più la portata media di lungo periodo. Pertanto, si procede con la definizione di una funzione che riceva un dataframe in input e che detrmini la portata derivabile $Q_{derivabile}$ ed il conseguente volume giornaliero.

La logica scelta per questo step è la seguente: si creano dei dizionari in modo che, digitato il nome del dataframe, vengano automaticamente messi nei calcoli il deflusso ecologico e la portata media associata. Per accedere applicare la funzione si utilizzi la nomenclatura: $daily\_withdrawal(df,\,\,"df")$


```python
#FUNZIONE CHE CALCOLA IL VOLUME DERIVABILE GIORNALIERO, DATO IN INPUT UN df
def daily_withdrawal(df, df_name):
    analysis_range = [] #lista vuota dentro cui vanno messi gli anni di analisi (2007...2023)
    first_year = df["DATA"].iloc[0].year
    last_year = df["DATA"].iloc[-1].year
    for i in range(first_year, last_year + 1, 1):
        analysis_range.append(i)
    
    DE_dictionary = {              #Dizionario che, digitata la chiave (nome del df), restituisce il corrispondente DE di ogni mese
        "df_tanaro": DE_albatanaro,
        "df_gesso": DE_andonnogesso,
        "df_carignano": DE_carignanopo,
        "df_po": DE_sansebpo,
        "df_dora": DE_verolengodorab
    }
    
    Qm_dictionary = {             # Dizionario che, digitata la chiave (nome del df), restituisce la corrispondente Qmedia
        "df_tanaro": Qm_albatanaro,
        "df_gesso": Qm_andonnogesso,
        "df_carignano": Qm_carignanopo,
        "df_po": Qm_sansebpo,
        "df_dora": Qm_verolengodorab
    }

    DE = DE_dictionary.get(df_name) # Comando che esegue l'operazione "ricevo key (nome df) -> accedo al df corretto -> prendo il corrispondente DE"
    Qm = Qm_dictionary.get(df_name) # Comando che esegue l'operazione "ricevo key (nome df) -> accedo al df corretto -> prendo il corrispondente Qm"
    
    Deflusso_ecologico = []
    
    for data in df["DATA"]:
        Deflusso_ecologico.append(DE[data.month - 1]) # Comando che estrae l'elemento della lista DE corretto a seconda del mese. Il -1 c'è perché il conto va ritarato all'indice della lista che inizia da 0 
    
    df["DE"] = Deflusso_ecologico
    df["Q-DE"] = df["Portata fiume (m³/s)"] - df["DE"]
    df["Q-DE"] = df["Q-DE"].clip(lower=0)
    df["Q media"] = Qm
    df["Q derivata"] = np.minimum(df["Q-DE"], df["Q media"])
    df["Volume giornaliero derivato (mc)"] = df["Q derivata"]*86400 #Volume giornaliero = Portata [mc/s] * secondi in un giorno. 
    
    return df

```


```python
daily_withdrawal(df_po, "df_po")
```

    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:33: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["DE"] = Deflusso_ecologico
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:34: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q-DE"] = df["Portata fiume (m³/s)"] - df["DE"]
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:35: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q-DE"] = df["Q-DE"].clip(lower=0)
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:36: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q media"] = Qm
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:37: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q derivata"] = np.minimum(df["Q-DE"], df["Q media"])
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:38: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Volume giornaliero derivato (mc)"] = df["Q derivata"]*86400
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DATA</th>
      <th>Portata fiume (m³/s)</th>
      <th>DE</th>
      <th>Q-DE</th>
      <th>Q media</th>
      <th>Q derivata</th>
      <th>Volume giornaliero derivato (mc)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>307</th>
      <td>2008-01-01</td>
      <td>17.90</td>
      <td>7.12603</td>
      <td>10.77397</td>
      <td>125.234382</td>
      <td>10.77397</td>
      <td>9.308710e+05</td>
    </tr>
    <tr>
      <th>308</th>
      <td>2008-01-02</td>
      <td>18.50</td>
      <td>7.12603</td>
      <td>11.37397</td>
      <td>125.234382</td>
      <td>11.37397</td>
      <td>9.827110e+05</td>
    </tr>
    <tr>
      <th>309</th>
      <td>2008-01-03</td>
      <td>18.90</td>
      <td>7.12603</td>
      <td>11.77397</td>
      <td>125.234382</td>
      <td>11.77397</td>
      <td>1.017271e+06</td>
    </tr>
    <tr>
      <th>310</th>
      <td>2008-01-04</td>
      <td>22.60</td>
      <td>7.12603</td>
      <td>15.47397</td>
      <td>125.234382</td>
      <td>15.47397</td>
      <td>1.336951e+06</td>
    </tr>
    <tr>
      <th>311</th>
      <td>2008-01-05</td>
      <td>25.30</td>
      <td>7.12603</td>
      <td>18.17397</td>
      <td>125.234382</td>
      <td>18.17397</td>
      <td>1.570231e+06</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6146</th>
      <td>2023-12-27</td>
      <td>32.35</td>
      <td>7.12603</td>
      <td>25.22397</td>
      <td>125.234382</td>
      <td>25.22397</td>
      <td>2.179351e+06</td>
    </tr>
    <tr>
      <th>6147</th>
      <td>2023-12-28</td>
      <td>31.86</td>
      <td>7.12603</td>
      <td>24.73397</td>
      <td>125.234382</td>
      <td>24.73397</td>
      <td>2.137015e+06</td>
    </tr>
    <tr>
      <th>6148</th>
      <td>2023-12-29</td>
      <td>24.77</td>
      <td>7.12603</td>
      <td>17.64397</td>
      <td>125.234382</td>
      <td>17.64397</td>
      <td>1.524439e+06</td>
    </tr>
    <tr>
      <th>6149</th>
      <td>2023-12-30</td>
      <td>26.04</td>
      <td>7.12603</td>
      <td>18.91397</td>
      <td>125.234382</td>
      <td>18.91397</td>
      <td>1.634167e+06</td>
    </tr>
    <tr>
      <th>6150</th>
      <td>2023-12-31</td>
      <td>26.06</td>
      <td>7.12603</td>
      <td>18.93397</td>
      <td>125.234382</td>
      <td>18.93397</td>
      <td>1.635895e+06</td>
    </tr>
  </tbody>
</table>
<p>5840 rows × 7 columns</p>
</div>



## 3) Analisi dei volumi derivabili

### 3.A) APPROCCIO MULTI-ANNO 

Per l'approccio multi-anno si rende necessario deterinare il volume derivabile di mese in mese. Avendo definito la funzione che calcola il volume giornaliero, può essere utile sfruttala inserendo all'interno di un'altra funzione che calcoli stavolta i volumi mensili.


```python
#FUNZIONE CHE RESTITUISCE I VOLUMI MENSILI DERIVABILI, DATO UN df IN INPUT
def monthly_withdrawal(df, df_name):
    df = daily_withdrawal(df, df_name) # si richiama la funzione per il calcolo del volume giornaliero
    df["Year"] = df["DATA"].dt.year #si crea la colonna "anno"
    df["Month"] = df["DATA"].dt.month #si crea la colonna "mese"
    monthly_volume = df.groupby(["Year", "Month"])["Volume giornaliero derivato (mc)"].sum().reset_index() #si prendono i volumi giornalieri di un mese di un certo anno e si sommano
    monthly_volume.rename(columns={"Volume giornaliero derivato (mc)" : "Volume mensile (mc)"}, inplace=True)
    
    return monthly_volume
```

Il passo successivo è applicare questa funzione a tutti i dataframe. Essendo che la funzione richiede di inserire anche il "nome" del dataframe, si utilizza zip che associa al dataframe (inteso come oggetto) la stringa. Inoltre, per il fatto che l'analisi statistica successiva verterà proprio sui volumi mensili derivabili, si sceglie di salvare questi dataframe a parte; per potervi accedere "per nome", si è scelto di utilizzare un dizionario. La nomenclatura da utilizzare per accedervi è $monthly\_volumes\_dict["nome\,\,df"]$


```python
dataframe_names = ["df_carignano", "df_po", "df_gesso", "df_tanaro", "df_dora"]
monthly_volumes_dict = {} #dizionario che conterrà i volumi mensili derivabili
for df,df_name in zip(dataframes, dataframe_names):
    monthly_volume = monthly_withdrawal(df, df_name)
    monthly_volumes_dict[df_name] = monthly_volume
```

    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:33: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["DE"] = Deflusso_ecologico
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:34: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q-DE"] = df["Portata fiume (m³/s)"] - df["DE"]
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:35: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q-DE"] = df["Q-DE"].clip(lower=0)
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:36: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q media"] = Qm
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:37: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Q derivata"] = np.minimum(df["Q-DE"], df["Q media"])
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\1075667670.py:38: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Volume giornaliero derivato (mc)"] = df["Q derivata"]*86400
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\469597990.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Year"] = df["DATA"].dt.year #si crea la colonna "anno"
    C:\Users\MATTEO IENTILE\AppData\Local\Temp\ipykernel_28352\469597990.py:5: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Month"] = df["DATA"].dt.month #si crea la colonna "mese"
    


```python
#ESEMPIO CON df_po
monthly_volumes_dict["df_po"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Month</th>
      <th>Volume mensile (mc)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2008</td>
      <td>1</td>
      <td>8.354820e+07</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2008</td>
      <td>2</td>
      <td>6.845223e+07</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2008</td>
      <td>3</td>
      <td>8.832164e+07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2008</td>
      <td>4</td>
      <td>4.094544e+07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2008</td>
      <td>5</td>
      <td>1.521153e+08</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>187</th>
      <td>2023</td>
      <td>8</td>
      <td>7.236262e+07</td>
    </tr>
    <tr>
      <th>188</th>
      <td>2023</td>
      <td>9</td>
      <td>1.722178e+08</td>
    </tr>
    <tr>
      <th>189</th>
      <td>2023</td>
      <td>10</td>
      <td>9.783462e+07</td>
    </tr>
    <tr>
      <th>190</th>
      <td>2023</td>
      <td>11</td>
      <td>8.890676e+07</td>
    </tr>
    <tr>
      <th>191</th>
      <td>2023</td>
      <td>12</td>
      <td>8.969815e+07</td>
    </tr>
  </tbody>
</table>
<p>192 rows × 3 columns</p>
</div>



### 3.B) APPROCCIO ANNO TIPO

Per ogni dataframe, si vogliono determinare l'anno medio e l'anno scarso, derivati del deflusso ecologico; dopdichè si calcola il volume derivabile per l'anno medio e per l'anno scarso. Conviene creare dei df nuovi contenenti solo le informazioni utili


```python
#FUNZIONE CHE, RICEVUTO UN DF IN INPUT, CALCOLA L'ANNO MEDIO E L'ANNO SCARSO
def poor_mean_year(df):
    first_year = df["DATA"].iloc[0].year
    last_year = df["DATA"].iloc[-1].year
    df_poormean = pd.DataFrame()
    
    df = df.sort_values(by="Portata fiume (m³/s)", ascending=True)
    
    for year in range(first_year, last_year+1, 1):
        df_poormean["Q",year] = df.loc[df["DATA"].dt.year == year, "Portata fiume (m³/s)"].reset_index(drop=True) #crea colonne con Q divisa anno per anno
        
    df_poormean["Q media"] = df_poormean.mean(axis=1) #calcolo media lungo una riga
    df_poormean["Q anno scarso"] = df_poormean.drop(columns=["Q media"]).quantile(0.2, axis=1) #calcolo quantile 0.2 lungo la riga, escludento la Q media
    
    return df_poormean

dfs_poormean = [poor_mean_year(df) for df in dataframes]
```


```python
poor_mean_year(df_po)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>(Q, 2008)</th>
      <th>(Q, 2009)</th>
      <th>(Q, 2010)</th>
      <th>(Q, 2011)</th>
      <th>(Q, 2012)</th>
      <th>(Q, 2013)</th>
      <th>(Q, 2014)</th>
      <th>(Q, 2015)</th>
      <th>(Q, 2016)</th>
      <th>(Q, 2017)</th>
      <th>(Q, 2018)</th>
      <th>(Q, 2019)</th>
      <th>(Q, 2020)</th>
      <th>(Q, 2021)</th>
      <th>(Q, 2022)</th>
      <th>(Q, 2023)</th>
      <th>Q media</th>
      <th>Q anno scarso</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4.39</td>
      <td>25.5</td>
      <td>18.9</td>
      <td>2.36</td>
      <td>12.50</td>
      <td>10.01</td>
      <td>35.37</td>
      <td>7.99</td>
      <td>6.88</td>
      <td>8.61</td>
      <td>9.99</td>
      <td>12.64</td>
      <td>20.96</td>
      <td>14.30</td>
      <td>8.19</td>
      <td>8.10</td>
      <td>12.918125</td>
      <td>7.99</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.41</td>
      <td>25.8</td>
      <td>19.6</td>
      <td>2.41</td>
      <td>13.31</td>
      <td>11.16</td>
      <td>40.08</td>
      <td>9.81</td>
      <td>7.23</td>
      <td>9.65</td>
      <td>12.66</td>
      <td>14.24</td>
      <td>23.46</td>
      <td>14.84</td>
      <td>9.62</td>
      <td>9.04</td>
      <td>14.207500</td>
      <td>9.04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.63</td>
      <td>28.1</td>
      <td>20.1</td>
      <td>3.11</td>
      <td>14.64</td>
      <td>11.68</td>
      <td>40.36</td>
      <td>10.59</td>
      <td>7.57</td>
      <td>9.74</td>
      <td>14.62</td>
      <td>14.40</td>
      <td>23.48</td>
      <td>14.96</td>
      <td>9.93</td>
      <td>9.23</td>
      <td>14.821250</td>
      <td>9.23</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.80</td>
      <td>29.1</td>
      <td>20.1</td>
      <td>3.24</td>
      <td>14.69</td>
      <td>13.15</td>
      <td>47.46</td>
      <td>11.15</td>
      <td>8.02</td>
      <td>10.97</td>
      <td>14.72</td>
      <td>14.48</td>
      <td>24.18</td>
      <td>15.16</td>
      <td>10.30</td>
      <td>9.57</td>
      <td>15.693125</td>
      <td>9.57</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.87</td>
      <td>29.5</td>
      <td>20.4</td>
      <td>3.33</td>
      <td>14.83</td>
      <td>15.32</td>
      <td>49.89</td>
      <td>11.20</td>
      <td>8.36</td>
      <td>11.15</td>
      <td>17.37</td>
      <td>15.46</td>
      <td>25.44</td>
      <td>15.65</td>
      <td>10.36</td>
      <td>9.67</td>
      <td>16.425000</td>
      <td>9.67</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>360</th>
      <td>1373.00</td>
      <td>990.0</td>
      <td>1060.0</td>
      <td>1367.00</td>
      <td>458.62</td>
      <td>1241.13</td>
      <td>804.80</td>
      <td>583.22</td>
      <td>681.60</td>
      <td>261.41</td>
      <td>973.47</td>
      <td>978.01</td>
      <td>481.02</td>
      <td>270.16</td>
      <td>130.68</td>
      <td>571.60</td>
      <td>764.107500</td>
      <td>458.62</td>
    </tr>
    <tr>
      <th>361</th>
      <td>1389.00</td>
      <td>1272.0</td>
      <td>1122.0</td>
      <td>1398.00</td>
      <td>463.21</td>
      <td>1370.77</td>
      <td>858.73</td>
      <td>599.20</td>
      <td>682.28</td>
      <td>263.83</td>
      <td>1022.15</td>
      <td>1042.04</td>
      <td>539.94</td>
      <td>376.18</td>
      <td>132.26</td>
      <td>649.65</td>
      <td>823.827500</td>
      <td>463.21</td>
    </tr>
    <tr>
      <th>362</th>
      <td>1420.00</td>
      <td>1341.0</td>
      <td>1162.0</td>
      <td>1703.00</td>
      <td>584.26</td>
      <td>1397.51</td>
      <td>884.95</td>
      <td>601.03</td>
      <td>1718.37</td>
      <td>280.64</td>
      <td>1092.48</td>
      <td>1175.47</td>
      <td>637.26</td>
      <td>433.74</td>
      <td>139.56</td>
      <td>723.60</td>
      <td>955.929375</td>
      <td>584.26</td>
    </tr>
    <tr>
      <th>363</th>
      <td>1526.00</td>
      <td>1420.0</td>
      <td>2365.0</td>
      <td>2072.00</td>
      <td>682.06</td>
      <td>1413.63</td>
      <td>1208.12</td>
      <td>634.08</td>
      <td>1921.35</td>
      <td>298.10</td>
      <td>1656.06</td>
      <td>2457.92</td>
      <td>715.74</td>
      <td>464.55</td>
      <td>142.63</td>
      <td>1011.47</td>
      <td>1249.294375</td>
      <td>634.08</td>
    </tr>
    <tr>
      <th>364</th>
      <td>2474.00</td>
      <td>2123.0</td>
      <td>3061.0</td>
      <td>2134.00</td>
      <td>827.23</td>
      <td>1807.30</td>
      <td>1688.49</td>
      <td>638.57</td>
      <td>3879.81</td>
      <td>376.87</td>
      <td>2117.89</td>
      <td>3103.34</td>
      <td>1197.07</td>
      <td>565.48</td>
      <td>165.18</td>
      <td>1555.04</td>
      <td>1732.141875</td>
      <td>638.57</td>
    </tr>
  </tbody>
</table>
<p>365 rows × 18 columns</p>
</div>




```python
#FUNZIONE CHE CALCOLA ANNO MEDIO E ANNO SCARSO DEPURATI DAL DEFLUSSO ECOLOGICO
def poor_mean_ecologic(df):
    first_year = df["DATA"].iloc[0].year
    last_year = df["DATA"].iloc[-1].year
    df_de = pd.DataFrame()
    df = df.sort_values(by="Portata fiume (m³/s)", ascending=True)
    for year in range(first_year, last_year+1, 1):
        df_de["Q-DE",year] = df.loc[df["DATA"].dt.year == year, "Q-DE"].reset_index(drop=True)
    
    df_de["Q-DE media"] = df_de.mean(axis=1)
    df_de["Q-DE anno scarso"] = df_de.drop(columns=["Q-DE media"]).quantile(0.2, axis=1)
    
    return df, df_de
```


```python
poor_mean_ecologic(df_po)
```




    (           DATA  Portata fiume (m³/s)         DE         Q-DE     Q media  \
     1627 2011-08-13                  2.36   4.988221     0.000000  125.234382   
     1635 2011-08-21                  2.41   4.988221     0.000000  125.234382   
     1640 2011-08-26                  3.11   4.988221     0.000000  125.234382   
     1624 2011-08-10                  3.24   4.988221     0.000000  125.234382   
     1632 2011-08-18                  3.33   4.988221     0.000000  125.234382   
     ...         ...                   ...        ...          ...         ...   
     4653 2019-11-25               2457.92   4.988221  2452.931779  125.234382   
     457  2008-05-30               2474.00  14.252059  2459.747941  125.234382   
     1204 2010-06-16               3061.00  14.252059  3046.747941  125.234382   
     4652 2019-11-24               3103.34   4.988221  3098.351779  125.234382   
     3558 2016-11-25               3879.81   4.988221  3874.821779  125.234382   
     
           Q derivata  Volume giornaliero derivato (mc)  Year  Month  
     1627    0.000000                      0.000000e+00  2011      8  
     1635    0.000000                      0.000000e+00  2011      8  
     1640    0.000000                      0.000000e+00  2011      8  
     1624    0.000000                      0.000000e+00  2011      8  
     1632    0.000000                      0.000000e+00  2011      8  
     ...          ...                               ...   ...    ...  
     4653  125.234382                      1.082025e+07  2019     11  
     457   125.234382                      1.082025e+07  2008      5  
     1204  125.234382                      1.082025e+07  2010      6  
     4652  125.234382                      1.082025e+07  2019     11  
     3558  125.234382                      1.082025e+07  2016     11  
     
     [5840 rows x 9 columns],
          (Q-DE, 2008)  (Q-DE, 2009)  (Q-DE, 2010)  (Q-DE, 2011)  (Q-DE, 2012)  \
     0        0.000000     20.511779     13.911779      0.000000      0.000000   
     1        0.000000     20.811779     14.611779      0.000000      8.321779   
     2        0.000000     23.111779     15.111779      0.000000      9.651779   
     3        0.000000     24.111779     15.111779      0.000000      9.701779   
     4        0.000000     24.511779     15.411779      0.000000      9.841779   
     ..            ...           ...           ...           ...           ...   
     360   1368.011779    975.747941   1045.747941   1362.011779    444.367941   
     361   1374.747941   1257.747941   1107.747941   1393.011779    448.957941   
     362   1412.873970   1326.747941   1147.747941   1695.873970    570.007941   
     363   1518.873970   1405.747941   2350.747941   2067.011779    667.807941   
     364   2459.747941   2108.747941   3046.747941   2129.011779    822.241779   
     
          (Q-DE, 2013)  (Q-DE, 2014)  (Q-DE, 2015)  (Q-DE, 2016)  (Q-DE, 2017)  \
     0        5.021779     30.381779      3.001779      1.891779      3.621779   
     1        6.171779     35.091779      4.821779      2.241779      4.661779   
     2        6.691779     35.371779      5.601779      2.581779      4.751779   
     3        8.161779     42.471779      6.161779      3.031779      5.981779   
     4       10.331779     44.901779      6.211779      3.371779      6.161779   
     ..            ...           ...           ...           ...           ...   
     360   1226.877941    799.811779    576.093970    667.347941    247.157941   
     361   1356.517941    853.741779    584.947941    677.291779    249.577941   
     362   1383.257941    879.961779    586.777941   1713.381779    273.513970   
     363   1399.377941   1200.993970    619.827941   1916.361779    283.847941   
     364   1793.047941   1681.363970    631.443970   3874.821779    369.743970   
     
          (Q-DE, 2018)  (Q-DE, 2019)  (Q-DE, 2020)  (Q-DE, 2021)  (Q-DE, 2022)  \
     0        5.001779      7.651779     15.971779      9.311779      0.000000   
     1        7.671779      9.251779     18.471779      9.851779      0.000000   
     2        9.631779      9.411779     18.491779      9.971779      4.941779   
     3        9.731779      9.491779     19.191779     10.171779      0.000000   
     4       12.381779     10.471779     20.451779     10.661779      0.000000   
     ..            ...           ...           ...           ...           ...   
     360    968.481779    973.021779    466.767941    265.171779    116.427941   
     361   1015.023970   1037.051779    525.687941    361.927941    118.007941   
     362   1087.491779   1170.481779    623.007941    428.751779    134.571779   
     363   1651.071779   2452.931779    701.487941    459.561779    128.377941   
     364   2112.901779   3098.351779   1192.081779    551.227941    150.927941   
     
          (Q-DE, 2023)   Q-DE media  Q-DE anno scarso  
     0        3.111779     7.461959          0.000000  
     1        4.051779     9.127071          2.241779  
     2        4.241779     9.972807          4.241779  
     3        4.581779    10.493946          3.031779  
     4        4.681779    11.212071          3.371779  
     ..            ...          ...               ...  
     360    557.347941   753.774757        444.367941  
     361    635.397941   812.336777        448.957941  
     362    709.347941   946.487386        570.007941  
     363    997.217941  1238.828019        619.827941  
     364   1540.787941  1722.699886        631.443970  
     
     [365 rows x 18 columns])



#### 3.B.1) VOLUME DERIVABILE ANNO MEDIO 


```python
# FUNZIONE CHE SETUPPA IL DATAFRAME PER L'ANALISI DELL'ANNO MEDIO: si vuole riunire in un unico dataset la Q-DE media, Q disponibile per anno medio e Q derivata per anno medio
def mean_year(df):
    Qmean = np.mean(df["Portata fiume (m³/s)"])
    df, df_de = poor_mean_ecologic(df)
    mean_year_df = pd.DataFrame()
    mean_year_df["Q-DE media"] = df_de["Q-DE media"]
    mean_year_df = mean_year_df.sort_values(by="Q-DE media", ascending=True)
    mean_year_df["d"] = np.arange(365, 0, -1)
    mean_year_df["F sup"] = mean_year_df["d"] / 366
    mean_year_df["Q max derivabile"] = np.full(shape=len(mean_year_df), fill_value=Qmean)
    mean_year_df["Q disponibile"] = [i if i >= 0 else 0 for i in mean_year_df["Q-DE media"]]
    mean_year_df["Q derivata"] = np.minimum(mean_year_df["Q max derivabile"], mean_year_df["Q disponibile"])
    
    
    return mean_year_df, df
```


```python
# FUNZIONE CHE PLOTTA LA CURVA DI DURATA DELL'ANNO MEDIO E CALCOLA IL VOLUME DERIVABILE (con il metodo trapz), sempre per l'anno MEDIO
def mean_withdrawable_volume(df):
    mean_year_df, df = mean_year(df)
    plt.figure(figsize=(14, 6))
    Frequenza = mean_year_df["F sup"]
    Qdisponibile = mean_year_df["Q disponibile"]
    Qmax_derivabile = mean_year_df["Q max derivabile"]
    Qderivata = mean_year_df["Q derivata"]

    plt.plot(Frequenza, Qdisponibile, linewidth=1, color="blue", label="CdD portata disponibile alla presa")
    plt.plot(Frequenza, Qmax_derivabile, linewidth=2, color="red", label="Massima Q derivabile dall' opera di presa")

    plt.fill_between(Frequenza, Qderivata, color="lightblue", alpha=1)
    plt.ylim(0, Qdisponibile[364])

    plt.title("Volume teorico derivabile per l'anno medio")
    plt.xlabel("Frequenza di superamento")
    plt.ylabel("Portata Q (mc/s)")
    plt.grid(True)
    #plt.yscale("log")
    plt.legend()
    plt.show()
    
    x = np.linspace(0,1, len(Qderivata))
    instant_mvolume = np.trapz(Qderivata, x)
    annual_mvolume = instant_mvolume*60*60*24*365
    annual_mvolume = round(annual_mvolume, 0)
    return f"Il volume derivabile per l'anno medio ammonta a {annual_mvolume:.0f} mc"
```


```python
#ESEMPIO CON df_po
mean_withdrawable_volume(df_po)
```


    
![png](output_56_0.png)
    





    "Il volume derivabile per l'anno medio ammonta a 2378507726 mc"



#### 3.B.2) VOLUME DERIVABILE ANNO SCARSO 


```python
# FUNZIONE CHE SETU-UPPA IL DATAFRAME PER L'ANNO SCARSO: si vuole riunire in un unico dataset la Q scarsa, Q-DE scarsa, Q disponibile per anno scarso e Q derivata per anno scarso
def poor_year(df):
    Qmean = np.mean(df["Portata fiume (m³/s)"])
    df, df_de = poor_mean_ecologic(df)
    poor_year_df = pd.DataFrame()
    poor_year_df["Q-DE anno scarso"] = df_de["Q-DE anno scarso"]
    poor_year_df = poor_year_df.sort_values(by="Q-DE anno scarso", ascending=True)
    poor_year_df["d"] = np.arange(365, 0, -1)
    poor_year_df["F sup"] = poor_year_df["d"] / 366
    poor_year_df["Q max derivabile"] = np.full(shape=len(poor_year_df), fill_value=Qmean)
    poor_year_df["Q disponibile"] = [i if i >= 0 else 0 for i in poor_year_df["Q-DE anno scarso"]]
    poor_year_df["Q derivata"] = np.minimum(poor_year_df["Q max derivabile"], poor_year_df["Q disponibile"])
    
    
    return poor_year_df, df
```


```python
# FUNZIONE CHE PLOTTA LA CURVA DI DURATA DELL'ANNO SCARSO E CALCOLA IL VOLUME DERIVABILE (con il metodo trapz), sempre per l'anno SCARSO
def poor_withdrawable_volume(df):
    poor_year_df, df = poor_year(df)
    plt.figure(figsize=(14, 6))
    Frequenza = poor_year_df["F sup"]
    Qdisponibile = poor_year_df["Q disponibile"]
    Qmax_derivabile = poor_year_df["Q max derivabile"]
    Qderivata = poor_year_df["Q derivata"]

    plt.plot(Frequenza, Qdisponibile, linewidth=1, color="blue", label="CdD portata disponibile alla presa")
    plt.plot(Frequenza, Qmax_derivabile, linewidth=2, color="red", label="Massima Q derivabile dall' opera di presa")

    plt.fill_between(Frequenza, Qderivata, color="lightblue", alpha=1)
    plt.ylim(0, Qdisponibile[364])

    plt.title("Volume teorico derivabile per l'anno scarso")
    plt.xlabel("Frequenza di superamento")
    plt.ylabel("Portata Q (mc/s)")
    plt.grid(True)
    #plt.yscale("log")
    plt.legend()
    plt.show()
    
    x = np.linspace(0,1, len(Qderivata))
    instant_pvolume = np.trapz(Qderivata, x)
    annual_pvolume = instant_pvolume*60*60*24*365
    annual_pvolume = round(annual_pvolume, 0)
    return f"Il volume derivabile per l'anno scarso ammonta a {annual_pvolume:.0f} mc"
```


```python
#ESEMPIO CON df_po
poor_withdrawable_volume(df_tanaro)
```


    
![png](output_60_0.png)
    





    "Il volume derivabile per l'anno scarso ammonta a 775232551 mc"




```python

```

## 4) Discussione

### 4.1) ANALISI STATISTICA MULTI-ANNO

#### 4.1.A) Media mese per mese


```python
monthly_volumes_dict
```




    {'df_carignano':      Year  Month  Volume mensile (mc)
     0    2007      1         5.533860e+07
     1    2007      2         4.635111e+07
     2    2007      3         3.954468e+07
     3    2007      4         7.050570e+07
     4    2007      5         1.148692e+08
     ..    ...    ...                  ...
     199  2023      8         3.448210e+07
     200  2023      9         2.843453e+07
     201  2023     10         3.623920e+07
     202  2023     11         4.564714e+07
     203  2023     12         4.565316e+07
     
     [204 rows x 3 columns],
     'df_po':      Year  Month  Volume mensile (mc)
     0    2008      1         8.354820e+07
     1    2008      2         6.845223e+07
     2    2008      3         8.832164e+07
     3    2008      4         4.094544e+07
     4    2008      5         1.521153e+08
     ..    ...    ...                  ...
     187  2023      8         7.236262e+07
     188  2023      9         1.722178e+08
     189  2023     10         9.783462e+07
     190  2023     11         8.890676e+07
     191  2023     12         8.969815e+07
     
     [192 rows x 3 columns],
     'df_gesso':      Year  Month  Volume mensile (mc)
     0    2008      1         0.000000e+00
     1    2008      2         0.000000e+00
     2    2008      3         0.000000e+00
     3    2008      4         0.000000e+00
     4    2008      5         4.941964e+06
     ..    ...    ...                  ...
     187  2023      8         0.000000e+00
     188  2023      9         0.000000e+00
     189  2023     10         2.183204e+06
     190  2023     11         2.357991e+06
     191  2023     12         1.255706e+06
     
     [192 rows x 3 columns],
     'df_tanaro':      Year  Month  Volume mensile (mc)
     0    2007      1         4.652580e+07
     1    2007      2         3.509319e+07
     2    2007      3         4.192068e+07
     3    2007      4         9.358609e+07
     4    2007      5         6.860631e+07
     ..    ...    ...                  ...
     199  2023      8         2.220179e+07
     200  2023      9         4.254797e+07
     201  2023     10         6.697000e+07
     202  2023     11         8.024605e+07
     203  2023     12         6.762366e+07
     
     [204 rows x 3 columns],
     'df_dora':      Year  Month  Volume mensile (mc)
     0    2002      1         7.662756e+07
     1    2002      2         9.234687e+07
     2    2002      3         7.187833e+07
     3    2002      4         1.433884e+06
     4    2002      5         1.328727e+08
     ..    ...    ...                  ...
     259  2023      8         4.190912e+07
     260  2023      9         1.028980e+08
     261  2023     10         9.111576e+07
     262  2023     11         9.587798e+07
     263  2023     12         6.974062e+07
     
     [264 rows x 3 columns]}




```python
#ESEMPIO CON UN SOLO DATAFRAME PER IL CALCOLO DEL VOLUME MENSILE MEDIO
monthly_volumes_dict["df_po"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Month</th>
      <th>Volume mensile (mc)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2008</td>
      <td>1</td>
      <td>8.354820e+07</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2008</td>
      <td>2</td>
      <td>6.845223e+07</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2008</td>
      <td>3</td>
      <td>8.832164e+07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2008</td>
      <td>4</td>
      <td>4.094544e+07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2008</td>
      <td>5</td>
      <td>1.521153e+08</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>187</th>
      <td>2023</td>
      <td>8</td>
      <td>7.236262e+07</td>
    </tr>
    <tr>
      <th>188</th>
      <td>2023</td>
      <td>9</td>
      <td>1.722178e+08</td>
    </tr>
    <tr>
      <th>189</th>
      <td>2023</td>
      <td>10</td>
      <td>9.783462e+07</td>
    </tr>
    <tr>
      <th>190</th>
      <td>2023</td>
      <td>11</td>
      <td>8.890676e+07</td>
    </tr>
    <tr>
      <th>191</th>
      <td>2023</td>
      <td>12</td>
      <td>8.969815e+07</td>
    </tr>
  </tbody>
</table>
<p>192 rows × 3 columns</p>
</div>




```python
dfgrouped = monthly_volumes_dict["df_po"].groupby("Month")
dfgrouped.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Volume mensile (mc)</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2015.5</td>
      <td>1.687850e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015.5</td>
      <td>1.746187e+08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015.5</td>
      <td>2.084759e+08</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015.5</td>
      <td>1.935161e+08</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2015.5</td>
      <td>2.714582e+08</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2015.5</td>
      <td>2.752716e+08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2015.5</td>
      <td>1.409710e+08</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2015.5</td>
      <td>9.476341e+07</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2015.5</td>
      <td>1.604506e+08</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2015.5</td>
      <td>1.732362e+08</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2015.5</td>
      <td>1.982435e+08</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2015.5</td>
      <td>1.815893e+08</td>
    </tr>
  </tbody>
</table>
</div>




```python
#CREAZIONE DI UNA FUNZIONE CHE SVOLGA QUESTO CONTO A PARTIRE DA UN DF ENTRATA:
def mean_volume_derivable(df):
    dfgrouped = df.groupby("Month")
    result = dfgrouped.mean()
    return result
```


```python
mean_volume_derivable(monthly_volumes_dict["df_po"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Volume mensile (mc)</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2015.5</td>
      <td>1.687850e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015.5</td>
      <td>1.746187e+08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015.5</td>
      <td>2.084759e+08</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015.5</td>
      <td>1.935161e+08</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2015.5</td>
      <td>2.714582e+08</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2015.5</td>
      <td>2.752716e+08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2015.5</td>
      <td>1.409710e+08</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2015.5</td>
      <td>9.476341e+07</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2015.5</td>
      <td>1.604506e+08</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2015.5</td>
      <td>1.732362e+08</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2015.5</td>
      <td>1.982435e+08</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2015.5</td>
      <td>1.815893e+08</td>
    </tr>
  </tbody>
</table>
</div>



#### 4.1.B) Mediana mese per mese


```python
#CREAZIONE DI UNA FUNZIONE CHE SVOLGA QUESTO CONTO A PARTIRE DA UN DF ENTRATA:
def median_volume_derivable(df):
    dfgrouped = df.groupby("Month")
    result = dfgrouped.quantile(0.5)
    return result
```


```python
median_volume_derivable(monthly_volumes_dict["df_po"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Volume mensile (mc)</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2015.5</td>
      <td>1.722175e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2015.5</td>
      <td>1.753333e+08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2015.5</td>
      <td>1.980677e+08</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2015.5</td>
      <td>2.320705e+08</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2015.5</td>
      <td>2.954090e+08</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2015.5</td>
      <td>3.154618e+08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2015.5</td>
      <td>1.454131e+08</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2015.5</td>
      <td>7.170317e+07</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2015.5</td>
      <td>1.651286e+08</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2015.5</td>
      <td>1.557977e+08</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2015.5</td>
      <td>1.918681e+08</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2015.5</td>
      <td>1.703565e+08</td>
    </tr>
  </tbody>
</table>
</div>



#### 4.1.C) Quantile 0.2 per mese


```python
#CREAZIONE DI UNA FUNZIONE CHE SVOLGA QUESTO CONTO A PARTIRE DA UN DF ENTRATA:
def poory_volume_derivable(df):
    dfgrouped = df.groupby("Month")
    result = dfgrouped.quantile(0.2)
    return result
```


```python
poory_volume_derivable(monthly_volumes_dict["df_po"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Volume mensile (mc)</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2011.0</td>
      <td>7.709931e+07</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011.0</td>
      <td>9.074689e+07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011.0</td>
      <td>9.290014e+07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011.0</td>
      <td>6.144148e+07</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2011.0</td>
      <td>2.091501e+08</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2011.0</td>
      <td>2.462347e+08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2011.0</td>
      <td>6.640057e+07</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2011.0</td>
      <td>5.432272e+07</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2011.0</td>
      <td>1.215549e+08</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2011.0</td>
      <td>1.062362e+08</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2011.0</td>
      <td>1.191615e+08</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2011.0</td>
      <td>8.969815e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
